﻿# WhatSub 한글 패치 설치 스크립트 (만든이: 랑데부)
param([string]$GameDir = "")
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path

function Test-GameDir($d) { return ($d -and (Test-Path (Join-Path $d "Sub\Binaries\Win64\Sub-Win64-Shipping.exe"))) }

function Find-GameDir {
    $cands = @((Split-Path -Parent $Here), $Here)
    try {
        $steam = (Get-ItemProperty "HKCU:\Software\Valve\Steam" -ErrorAction Stop).SteamPath
        if ($steam) {
            $cands += (Join-Path $steam "steamapps\common\WhatSub")
            $vdf = Join-Path $steam "steamapps\libraryfolders.vdf"
            if (Test-Path $vdf) {
                foreach ($m in [regex]::Matches((Get-Content $vdf -Raw), '"path"\s+"([^"]+)"')) {
                    $cands += (Join-Path ($m.Groups[1].Value -replace '\\','\') "steamapps\common\WhatSub")
                }
            }
        }
    } catch {}
    foreach ($c in $cands) { if (Test-GameDir $c) { return (Resolve-Path $c).Path } }
    return $null
}

Write-Host "=== WhatSub 한글 패치 설치 (만든이: 랑데부) ===" -ForegroundColor Cyan
if (-not (Test-GameDir $GameDir)) { $GameDir = Find-GameDir }
while (-not (Test-GameDir $GameDir)) {
    $GameDir = Read-Host "WhatSub 게임 폴더를 찾지 못했어요. 폴더 경로를 입력하세요 (예: D:\SteamLibrary\steamapps\common\WhatSub)"
    $GameDir = $GameDir.Trim('"')
}
Write-Host "게임 폴더: $GameDir"

if (Get-Process -Name "Sub-Win64-Shipping" -ErrorAction SilentlyContinue) {
    Write-Host "게임이 실행 중이에요. 게임을 끄고 다시 실행해 주세요." -ForegroundColor Red; exit 1
}

# 1) 모드 파일 복사
$paks = Join-Path $GameDir "Sub\Content\Paks"
foreach ($f in "Sub-Korean_v4_P.pak","Sub-Korean_v4_P.utoc","Sub-Korean_v4_P.ucas") {
    Copy-Item (Join-Path $Here "Paks\$f") (Join-Path $paks $f) -Force
}
Write-Host "[1/3] 한글 패치 파일 복사 완료"

# 2) 실행 파일의 로딩 문구 한글화 (원본 백업 후)
$exe = Join-Path $GameDir "Sub\Binaries\Win64\Sub-Win64-Shipping.exe"
$bak = "$exe.korean-backup"
$pairs = [ordered]@{ "Generating world" = "월드 생성 중"; "Placing structures" = "구조물 배치 중"; "Routing currents" = "해류 계산 중" }
$bytes = [IO.File]::ReadAllBytes($exe)
$latin = [Text.Encoding]::GetEncoding(28591)
$text = $latin.GetString($bytes)
$changed = 0
foreach ($en in $pairs.Keys) {
    $old = [Text.Encoding]::Unicode.GetBytes($en + [char]0)
    $new = [Text.Encoding]::Unicode.GetBytes($pairs[$en] + [char]0)
    $i = $text.IndexOf($latin.GetString($old), [StringComparison]::Ordinal)
    if ($i -lt 0) { continue }
    for ($k = 0; $k -lt $old.Length; $k++) { $bytes[$i + $k] = if ($k -lt $new.Length) { $new[$k] } else { 0 } }
    $changed++
}
if ($changed -gt 0) {
    if (-not (Test-Path $bak)) { Copy-Item $exe $bak }
    [IO.File]::WriteAllBytes($exe, $bytes)
    Write-Host "[2/3] 로딩 문구 한글화 완료 ($changed 개, 원본 백업: Sub-Win64-Shipping.exe.korean-backup)"
} else {
    Write-Host "[2/3] 로딩 문구: 이미 적용되었거나 게임 버전이 달라 건너뜀"
}

# 3) 게임 언어를 한국어로 설정
$cfgDir = Join-Path $env:LOCALAPPDATA "Sub\Saved\Config\Windows"
$ini = Join-Path $cfgDir "GameUserSettings.ini"
New-Item -ItemType Directory -Force $cfgDir | Out-Null
$content = if (Test-Path $ini) { [IO.File]::ReadAllText($ini) } else { "" }
if ($content -match '(?m)^Culture=') {
    $content = [regex]::Replace($content, '(?m)^Culture=.*$', 'Culture=ko')
} elseif ($content -match '(?m)^\[Internationalization\]') {
    $content = [regex]::Replace($content, '(?m)^\[Internationalization\]\s*$', "[Internationalization]`r`nCulture=ko")
} else {
    $content = $content.TrimEnd() + "`r`n`r`n[Internationalization]`r`nCulture=ko`r`n"
}
[IO.File]::WriteAllText($ini, $content)
Write-Host "[3/3] 게임 언어를 한국어로 설정 완료"
Write-Host ""
Write-Host "설치가 끝났어요! 게임을 실행하세요." -ForegroundColor Green
