﻿# WhatSub 한글 패치 제거 스크립트 (만든이: 랑데부)
param([string]$GameDir = "")
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
function Test-GameDir($d) { return ($d -and (Test-Path (Join-Path $d "Sub\Binaries\Win64\Sub-Win64-Shipping.exe"))) }
function Find-GameDir {
    $cands = @((Split-Path -Parent $Here), $Here)
    try {
        $steam = (Get-ItemProperty "HKCU:\Software\Valve\Steam" -ErrorAction Stop).SteamPath
        if ($steam) {
            $cands += (Join-Path $steam "steamapps\common\WhatSub")
            $vdf = Join-Path $steam "steamapps\libraryfolders.vdf"
            if (Test-Path $vdf) {
                foreach ($m in [regex]::Matches((Get-Content $vdf -Raw), '"path"\s+"([^"]+)"')) {
                    $cands += (Join-Path ($m.Groups[1].Value -replace '\\','\') "steamapps\common\WhatSub")
                }
            }
        }
    } catch {}
    foreach ($c in $cands) { if (Test-GameDir $c) { return (Resolve-Path $c).Path } }
    return $null
}
Write-Host "=== WhatSub 한글 패치 제거 ===" -ForegroundColor Cyan
if (-not (Test-GameDir $GameDir)) { $GameDir = Find-GameDir }
while (-not (Test-GameDir $GameDir)) { $GameDir = (Read-Host "WhatSub 게임 폴더 경로를 입력하세요").Trim('"') }
if (Get-Process -Name "Sub-Win64-Shipping" -ErrorAction SilentlyContinue) { Write-Host "게임을 끄고 다시 실행해 주세요." -ForegroundColor Red; exit 1 }
$paks = Join-Path $GameDir "Sub\Content\Paks"
foreach ($f in "Sub-Korean_v4_P.pak","Sub-Korean_v4_P.utoc","Sub-Korean_v4_P.ucas") { Remove-Item (Join-Path $paks $f) -ErrorAction SilentlyContinue }
$exe = Join-Path $GameDir "Sub\Binaries\Win64\Sub-Win64-Shipping.exe"
if (Test-Path "$exe.korean-backup") { Move-Item "$exe.korean-backup" $exe -Force; Write-Host "실행 파일을 원본으로 되돌렸어요." }
$ini = Join-Path $env:LOCALAPPDATA "Sub\Saved\Config\Windows\GameUserSettings.ini"
if (Test-Path $ini) { $c = [IO.File]::ReadAllText($ini); [IO.File]::WriteAllText($ini, [regex]::Replace($c, '(?m)^Culture=ko\r?\n?', '')) }
Write-Host "제거가 끝났어요. 게임이 영어로 돌아갑니다." -ForegroundColor Green
